package com.finewine.training

import android.content.Context
import java.io.File

/** Keeps the active LoRA adapter, the previous one (for rollback), and the incoming candidate. */
class AdapterManager(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("training", Context.MODE_PRIVATE)
    private val dir = File(ctx.filesDir, "adapters").apply { mkdirs() }

    fun candidateFile() = File(dir, "candidate.bin")
    fun active(): File? = prefs.getString("active", null)?.let { File(dir, it) }?.takeIf { it.exists() }

    fun accept() {
        val name = "adapter-${System.currentTimeMillis()}.bin"
        candidateFile().renameTo(File(dir, name))
        prefs.edit().putString("previous", prefs.getString("active", null)).putString("active", name)
            .putLong("cutoff", prefs.getLong("pending_cutoff", 0L)).apply()
    }
    fun reject() { candidateFile().delete() }

    /** Returns false if there is no adapter to roll back from. */
    fun rollback(): Boolean {
        if (prefs.getString("active", null) == null) return false
        prefs.edit().putString("active", prefs.getString("previous", null)).putString("previous", null).apply()
        return true
    }
    fun status(): String =
        "Active adapter: ${prefs.getString("active", null) ?: "none (base model)"}\n" +
        "Last dataset: ${prefs.getString("last_export", "none yet")}"
}
