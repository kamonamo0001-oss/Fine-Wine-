package com.finewine

/** Process-wide flags so a background job never loads a second copy of the model next to the app's own. */
object AppState {
    @Volatile var engineLoaded = false
}
