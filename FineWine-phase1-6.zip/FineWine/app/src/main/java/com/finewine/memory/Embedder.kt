package com.finewine.memory

import java.nio.ByteBuffer
import kotlin.math.sqrt

/** Offline hashed bag-of-words embedder. No model file needed; swap for a neural embedder later. */
object Embedder {
    private const val DIM = 256
    fun embed(text: String): FloatArray {
        val v = FloatArray(DIM)
        text.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length > 1 }.forEach { w ->
            val h = w.hashCode()
            val idx = (h and 0x7fffffff) % DIM
            v[idx] += if ((h shr 31) == 0) 1f else -1f
        }
        val n = sqrt(v.fold(0f) { a, x -> a + x * x })
        if (n > 0f) for (i in v.indices) v[i] /= n
        return v
    }
    fun toBytes(v: FloatArray): ByteArray =
        ByteBuffer.allocate(v.size * 4).also { b -> v.forEach { b.putFloat(it) } }.array()
    fun fromBytes(b: ByteArray): FloatArray {
        val bb = ByteBuffer.wrap(b); return FloatArray(b.size / 4) { bb.getFloat() }
    }
    fun cosine(a: FloatArray, b: FloatArray): Float { var s = 0f; for (i in a.indices) s += a[i] * b[i]; return s }
}
