package com.finewine.tools

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/** Runs JavaScript in an isolated headless WebView (no network, no DOM use). Returns output or "ERROR: ...". */
class CodeSandbox(private val ctx: Context) {
    /** In-page run time (ms) of the most recent run. */
    @Volatile var lastMs = 0.0

    suspend fun run(code: String, timeoutMs: Long = 5000): String = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { cont ->
            val wv = WebView(ctx)
            wv.settings.javaScriptEnabled = true
            wv.settings.blockNetworkLoads = true
            val out = StringBuffer()
            val handler = Handler(Looper.getMainLooper())
            var finished = false
            fun finish(r: String) {
                if (finished) return
                finished = true; handler.removeCallbacksAndMessages(null); wv.destroy()
                if (cont.isActive) cont.resume(r)
            }
            wv.addJavascriptInterface(object {
                @JavascriptInterface fun log(s: String) { out.append(s).append('\n') }
                @JavascriptInterface fun timing(ms: Double) { lastMs = ms }
                @JavascriptInterface fun done(err: String) {
                    handler.post { finish(if (err.isNotEmpty()) "ERROR: $err\n$out" else out.toString().ifBlank { "(no output)" }) }
                }
            }, "Bridge")
            handler.postDelayed({ finish("ERROR: timed out\n$out") }, timeoutMs)
            cont.invokeOnCancellation { handler.post { finish("cancelled") } }
            wv.loadDataWithBaseURL(null, page(code), "text/html", "utf-8", null)
        }
    }

    private fun page(code: String): String = """<script>
var __o=function(a){return a.map(function(x){try{return typeof x==='object'?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(' ')};
console.log=function(){Bridge.log(__o([].slice.call(arguments)))};console.error=console.log;console.warn=console.log;
window.onerror=function(m){Bridge.done(String(m));return true};
var __err='';var __t0=performance.now();
try{
/*USER*/
}catch(e){__err=String(e&&e.message||e)}
try{Bridge.timing(performance.now()-__t0)}catch(e){}
setTimeout(function(){Bridge.done(__err)},300);
</script>""".replace("/*USER*/", code.replace("</script>", "<\\/script>"))
}
