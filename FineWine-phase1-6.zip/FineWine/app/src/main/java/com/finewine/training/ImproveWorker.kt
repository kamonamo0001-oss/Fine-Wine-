package com.finewine.training

import android.content.Context
import androidx.work.*
import com.finewine.AppState
import com.finewine.llm.MediaPipeEngine
import com.finewine.memory.MemoryDb
import com.finewine.memory.MemoryStore
import com.finewine.tools.CodeSandbox
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.concurrent.TimeUnit

/** Nightly self-improvement while charging + idle. Skips if the app already holds the model in memory. */
class ImproveWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        val model = File(c.filesDir, "model.task")
        if (AppState.engineLoaded || !model.exists()) return Result.success()
        val engine = MediaPipeEngine(c)
        try {
            engine.load(model.absolutePath, AdapterManager(c).active()?.absolutePath)
            withTimeoutOrNull(8 * 60_000L) {
                SkillImprover(c, MemoryStore(MemoryDb.get(c).dao()), engine, CodeSandbox(c)).run(5)
            }
        } catch (_: Throwable) {
        } finally { engine.close() }
        return Result.success()
    }
    companion object {
        fun schedule(c: Context) {
            val req = PeriodicWorkRequestBuilder<ImproveWorker>(24, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiresCharging(true)
                    .setRequiresDeviceIdle(true).setRequiresBatteryNotLow(true).build()).build()
            WorkManager.getInstance(c).enqueueUniquePeriodicWork("nightly-improve", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
