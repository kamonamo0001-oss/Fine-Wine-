package com.finewine.llm

/** Anything that can turn a prompt into text. Swap implementations (MediaPipe, LiteRT-LM) freely. */
interface LlmEngine {
    val isReady: Boolean
    suspend fun load(modelPath: String, loraPath: String? = null)
    suspend fun generate(prompt: String): String
}
