package com.finewine.training

import com.finewine.llm.LlmEngine
import com.finewine.memory.MemoryEntity
import com.finewine.tools.CodeSandbox
import com.finewine.tools.Prompts

/**
 * Regression test against the AI's own past successes. A new adapter is only kept if it passes at least as
 * many of these as the current setup, which catches forgetting of skills it already had.
 */
object EvalGate {
    data class Task(val desc: String, val scene: Boolean)

    fun pickTasks(all: List<MemoryEntity>, n: Int = 8): List<Task> =
        all.filter { it.kind == "code" }.mapNotNull { m ->
            val t = m.text.lineSequence().firstOrNull()?.removePrefix("Task: ")?.trim().orEmpty()
            when {
                t.isBlank() -> null
                t.startsWith("3D model of ") -> Task(t.removePrefix("3D model of "), true)
                else -> Task(t, false)
            }
        }.distinctBy { it.desc }.shuffled().take(n)

    suspend fun passCount(engine: LlmEngine, sandbox: CodeSandbox, tasks: List<Task>): Int {
        var ok = 0
        for (t in tasks) {
            val rules = if (t.scene) Prompts.SCENE_RULES else Prompts.CODE_RULES
            val stubs = if (t.scene) Prompts.SCENE_STUBS else ""
            // no stored example in the prompt: this must test the model itself, not memory lookup
            val code = Prompts.extractCode(engine.generate(Prompts.codePrompt(rules, "", t.desc)))
            if (!sandbox.run("$stubs\n$code").startsWith("ERROR")) ok++
        }
        return ok
    }
}
