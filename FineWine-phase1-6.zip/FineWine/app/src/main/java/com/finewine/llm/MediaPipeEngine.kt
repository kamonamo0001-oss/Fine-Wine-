package com.finewine.llm

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Runs a local model fully on-device. LoRA (static, at load time) works only with GPU-converted supported models. */
class MediaPipeEngine(private val context: Context) : LlmEngine {
    private var llm: LlmInference? = null
    override val isReady get() = llm != null

    override suspend fun load(modelPath: String, loraPath: String?) = withContext(Dispatchers.Default) {
        llm?.close(); llm = null            // never keep a closed instance around if loading fails
        val b = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath).setMaxTokens(2048)
            .setTopK(40).setTemperature(0.4f).setRandomSeed(101)
        if (loraPath != null) b.setLoraPath(loraPath)
        llm = LlmInference.createFromOptions(context, b.build())
    }

    fun close() { llm?.close(); llm = null }

    override suspend fun generate(prompt: String): String = withContext(Dispatchers.Default) {
        (llm ?: error("Model not loaded")).generateResponse(prompt)
    }
}
