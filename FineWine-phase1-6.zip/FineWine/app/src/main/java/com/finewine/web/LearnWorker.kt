package com.finewine.web

import android.content.Context
import androidx.work.*
import com.finewine.memory.MemoryDb
import com.finewine.memory.MemoryStore
import java.util.concurrent.TimeUnit

/** Background auto-learning: revisits every watched topic on a schedule. */
class LearnWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val learner = WebLearner(MemoryStore(MemoryDb.get(applicationContext).dao()))
        Topics.all(applicationContext).forEach { t -> runCatching { learner.learnTopic(t) } }
        return Result.success()
    }
    companion object {
        fun schedule(c: Context) {
            val req = PeriodicWorkRequestBuilder<LearnWorker>(6, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build())
                .build()
            WorkManager.getInstance(c).enqueueUniquePeriodicWork("auto-learn", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
