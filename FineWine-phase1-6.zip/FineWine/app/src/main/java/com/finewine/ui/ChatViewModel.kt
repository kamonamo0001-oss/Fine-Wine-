package com.finewine.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.finewine.llm.MediaPipeEngine
import com.finewine.memory.MemoryDb
import com.finewine.memory.MemoryStore
import com.finewine.tools.CodeSandbox
import com.finewine.tools.Prompts
import com.finewine.tools.Scene3D
import com.finewine.training.AdapterManager
import com.finewine.training.DatasetBuilder
import com.finewine.training.EvalGate
import com.finewine.training.SkillImprover
import com.finewine.AppState
import com.finewine.web.Topics
import com.finewine.web.WebLearner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class Msg(val fromUser: Boolean, val text: String, val html: String? = null)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = MediaPipeEngine(app)
    private val memory = MemoryStore(MemoryDb.get(app).dao())
    private val learner = WebLearner(memory)
    private val sandbox = CodeSandbox(app)
    private val adapters = AdapterManager(app)
    private val dataset = DatasetBuilder(app, memory)
    private val improver = SkillImprover(app, memory, engine, sandbox)
    private val modelFile = File(app.filesDir, "model.task")
    val messages = mutableStateListOf<Msg>()
    val status = mutableStateOf("No model loaded. Import a .task model file.")
    val busy = mutableStateOf(false)

    init { if (modelFile.exists()) loadModel() }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            busy.value = true; status.value = "Copying model..."
            withContext(Dispatchers.IO) {
                getApplication<Application>().contentResolver.openInputStream(uri)!!.use { i ->
                    modelFile.outputStream().use { o -> i.copyTo(o) } }
            }
            busy.value = false; loadModel()
        }
    }

    private fun loadModel() {
        viewModelScope.launch {
            busy.value = true; status.value = "Loading model..."
            status.value = try { engine.load(modelFile.absolutePath, adapters.active()?.absolutePath); AppState.engineLoaded = true; "Ready (${memory.count()} memories)" }
            catch (e: Throwable) { "Load failed: ${e.message}" }
            busy.value = false
        }
    }

    fun send(text: String) {
        if (text.isBlank() || busy.value) return
        if (text.startsWith("/")) { command(text.trim()); return }
        if (!engine.isReady) return
        messages += Msg(true, text)
        viewModelScope.launch {
            busy.value = true
            val recalled = memory.recall(text).joinToString("\n") {
                "- ${it.text}" + if (it.source.isNotBlank()) " (source: ${it.source})" else "" }
            val history = memory.recent(6).filter { it.kind == "user" || it.kind == "assistant" }
                .joinToString("\n") { "${it.kind}: ${it.text}" }
            val prompt = buildString {
                append("You are Fine Wine AI, a helpful on-device assistant. Use memories only if relevant; cite sources when you use web memories; never invent facts.\n")
                if (recalled.isNotBlank()) append("Relevant memories:\n$recalled\n")
                if (history.isNotBlank()) append("Recent chat:\n$history\n")
                append("user: $text\nassistant:")
            }
            memory.remember(text, "user")
            val reply = try { engine.generate(prompt).trim() } catch (e: Throwable) { "Error: ${e.message}" }
            memory.remember(reply, "assistant")
            messages += Msg(false, reply)
            status.value = "Ready (${memory.count()} memories)"
            busy.value = false
        }
    }

    /** Copy -> test current setup -> test candidate -> keep only if it is at least as good, else restore. */
    fun importAdapter(uri: Uri) {
        if (busy.value) return
        tool {
            val modelPath = modelFile.absolutePath
            val activePath = adapters.active()?.absolutePath
            messages += Msg(false, "Copying adapter...")
            withContext(Dispatchers.IO) {
                getApplication<Application>().contentResolver.openInputStream(uri)!!.use { i ->
                    adapters.candidateFile().outputStream().use { o -> i.copyTo(o) } }
            }
            val tasks = EvalGate.pickTasks(memory.all())
            if (tasks.size < 3) {
                adapters.reject()
                messages += Msg(false, "Rejected for safety: I only have ${tasks.size} saved coding tasks to test with (need 3). Use /code a few times, then import again.")
                return@tool
            }
            messages += Msg(false, "Testing the current setup on ${tasks.size} past tasks...")
            val before = EvalGate.passCount(engine, sandbox, tasks)
            messages += Msg(false, "Current: $before/${tasks.size}. Loading the new adapter and testing...")
            val after = try {
                engine.load(modelPath, adapters.candidateFile().absolutePath)
                EvalGate.passCount(engine, sandbox, tasks)
            } catch (e: Throwable) { messages += Msg(false, "Adapter failed to load: ${e.message}"); -1 }
            if (after >= 0 && after >= before) {
                adapters.accept()
                messages += Msg(false, "Accepted: $after/${tasks.size} (was $before). The new adapter is active. /adapter rollback undoes it.")
            } else {
                adapters.reject(); engine.load(modelPath, activePath)
                messages += Msg(false, "Rejected: $after/${tasks.size} vs $before. Kept your current setup.")
            }
        }
    }

    // ---- tools -------------------------------------------------------------------------------

    /** Generate -> run -> if it fails, feed the error back to the model and fix (up to [retries] times). */
    private suspend fun codeLoop(task: String, rules: String, stubs: String, retries: Int = 2): Pair<String, String> {
        val example = memory.recall(task, 3).firstOrNull { it.kind == "code" }
            ?.let { "A similar solved example:\n${it.text}\n" } ?: ""
        var code = Prompts.extractCode(engine.generate(Prompts.codePrompt(rules, example, task)))
        var result = sandbox.run("$stubs\n$code")
        var n = 0
        while (result.startsWith("ERROR") && n < retries) {
            n++
            code = Prompts.extractCode(engine.generate(
                "$rules\nThis code failed:\n```\n$code\n```\nError: ${result.take(300)}\nFix it. Reply with one corrected code block only."))
            result = sandbox.run("$stubs\n$code")
        }
        return code to result
    }

    private fun tool(needsModel: Boolean = true, block: suspend () -> Unit) {
        if (needsModel && !engine.isReady) { messages += Msg(false, "Load a model first."); return }
        viewModelScope.launch {
            busy.value = true
            try { block() } catch (e: Throwable) { messages += Msg(false, "Error: ${e.message}") }
            status.value = "Ready (${memory.count()} memories)"; busy.value = false
        }
    }

    private fun command(cmd: String) {
        val ctx = getApplication<Application>()
        val arg = cmd.substringAfter(' ', "").trim()
        messages += Msg(true, cmd)
        when (cmd.substringBefore(' ').lowercase()) {
            "/learn" -> tool(needsModel = false) {
                if (arg.isBlank()) { messages += Msg(false, "Usage: /learn <url or topic>"); return@tool }
                messages += Msg(false, "Learning \"$arg\"...")
                messages += Msg(false, try {
                    if (arg.startsWith("http")) "Stored ${learner.learnUrl(arg)} new chunks from that page."
                    else learner.learnTopic(arg).let { "Read ${it.first} pages, stored ${it.second} new chunks." }
                } catch (e: Throwable) { "Couldn't learn that: ${e.message}" })
            }
            "/watch" -> { Topics.add(ctx, arg); messages += Msg(false, "Watching \"$arg\". I'll re-learn it automatically every ~6 hours when online.") }
            "/unwatch" -> { Topics.remove(ctx, arg); messages += Msg(false, "Stopped watching \"$arg\".") }
            "/topics" -> messages += Msg(false, Topics.all(ctx).ifEmpty { setOf("(none yet)") }.joinToString("\n"))
            "/code" -> tool {
                messages += Msg(false, "Writing and testing code...")
                val (code, res) = codeLoop(arg, Prompts.CODE_RULES, "")
                if (!res.startsWith("ERROR")) memory.remember("Task: $arg\nWorking JavaScript:\n$code", "code")
                messages += Msg(false, "Code:\n$code\n\nOutput:\n$res")
            }
            "/run" -> tool(needsModel = false) { messages += Msg(false, sandbox.run(arg)) }
            "/3d" -> tool {
                messages += Msg(false, "Designing the model...")
                val (code, res) = codeLoop(arg, Prompts.SCENE_RULES, Prompts.SCENE_STUBS)
                if (res.startsWith("ERROR")) messages += Msg(false, "Couldn't build a valid model: $res")
                else {
                    memory.remember("Task: 3D model of $arg\nWorking scene code:\n$code", "code")
                    messages += Msg(false, "Done. Drag to rotate; tap Save OBJ to export.", Scene3D.page(code))
                }
            }
            "/improve" -> when (arg.lowercase()) {
                "log" -> messages += Msg(false, improver.log())
                "undo" -> tool(needsModel = false) { messages += Msg(false, improver.undoLast()) }
                else -> tool {
                    messages += Msg(false, "Reviewing my saved skills and trying to improve them...")
                    messages += Msg(false, improver.run(5).lines.joinToString("\n").ifBlank { "Nothing to review yet. Use /code first." })
                }
            }
            "/train" -> tool(needsModel = false) {
                messages += Msg(false, dataset.build().let { r ->
                    r.note + if (r.file != null) "\n${r.fresh} new + ${r.replay} replay examples. Train it on a PC/Colab (see trainer/README.md), then tap Import adapter." else "" })
            }
            "/adapter" -> when (arg.lowercase()) {
                "rollback" -> tool {
                    messages += Msg(false, if (adapters.rollback()) {
                        engine.load(modelFile.absolutePath, adapters.active()?.absolutePath); "Rolled back.\n" + adapters.status()
                    } else "Nothing to roll back.")
                }
                else -> messages += Msg(false, adapters.status())
            }
            else -> messages += Msg(false, "Commands: /learn /watch /unwatch /topics /code <task> /run <js> /3d <description> /train /adapter [rollback] /improve [log|undo]")
        }
    }

    override fun onCleared() { AppState.engineLoaded = false; engine.close(); super.onCleared() }
}
