package com.finewine.tools

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.widget.Toast
import java.io.File

/** Lets the 3D viewer save its model as a Wavefront .obj file (opens in Blender, etc.). */
class ObjBridge(private val c: Context) {
    @JavascriptInterface
    fun saveObj(obj: String) {
        val dir = File(c.getExternalFilesDir(null), "models").apply { mkdirs() }
        val f = File(dir, "model-${System.currentTimeMillis()}.obj")
        f.writeText(obj)
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(c, "Saved: ${f.absolutePath}", Toast.LENGTH_LONG).show()
        }
    }
}
