package com.finewine.tools

/** Self-contained software 3D viewer. Model code uses box/sphere/cylinder/cone. Drag to rotate. */
object Scene3D {
    fun page(userCode: String): String = TEMPLATE.replace("/*USER*/", userCode.replace("</script>", "<\\/script>"))

    private val TEMPLATE = """<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#0b0b10;overflow:hidden}canvas{width:100%;height:100%;touch-action:none;display:block}
#b{position:absolute;top:8px;right:8px;background:#b00020;color:#fff;border:0;border-radius:6px;padding:6px 10px;font:13px sans-serif}
#m{position:absolute;left:8px;top:8px;color:#f66;font:12px sans-serif;max-width:60%}</style></head><body>
<canvas id="c"></canvas><button id="b">Save OBJ</button><div id="m"></div>
<script>
var meshes=[];
function msg(t){document.getElementById('m').textContent=t}
window.onerror=function(m){msg(String(m));return true};
function col(c){c=c||'#8899aa';if(c.charAt(0)==='#'&&c.length===7)return[parseInt(c.slice(1,3),16),parseInt(c.slice(3,5),16),parseInt(c.slice(5,7),16)];return[136,153,170]}
function mk(v,f,o){o=o||{};var x=o.x||0,y=o.y||0,z=o.z||0;meshes.push({v:v.map(function(p){return[p[0]+x,p[1]+y,p[2]+z]}),f:f,c:col(o.color)})}
function box(w,h,d,o){var a=w/2,b=h/2,c=d/2;
mk([[-a,-b,-c],[a,-b,-c],[a,b,-c],[-a,b,-c],[-a,-b,c],[a,-b,c],[a,b,c],[-a,b,c]],
[[0,2,1],[0,3,2],[4,5,6],[4,6,7],[0,1,5],[0,5,4],[2,3,7],[2,7,6],[0,4,7],[0,7,3],[1,2,6],[1,6,5]],o)}
function sphere(r,o){var R=10,S=16,v=[],f=[];
for(var i=0;i<=R;i++)for(var j=0;j<S;j++){var p=Math.PI*i/R,t=2*Math.PI*j/S;v.push([r*Math.sin(p)*Math.cos(t),r*Math.cos(p),r*Math.sin(p)*Math.sin(t)])}
for(var i=0;i<R;i++)for(var j=0;j<S;j++){var a=i*S+j,b=i*S+(j+1)%S,c=(i+1)*S+j,d=(i+1)*S+(j+1)%S;f.push([a,c,b],[b,c,d])}
mk(v,f,o)}
function cylinder(r,h,o){var S=20,v=[],f=[];
for(var j=0;j<S;j++){var t=2*Math.PI*j/S;v.push([r*Math.cos(t),-h/2,r*Math.sin(t)])}
for(var j=0;j<S;j++){var t=2*Math.PI*j/S;v.push([r*Math.cos(t),h/2,r*Math.sin(t)])}
v.push([0,-h/2,0],[0,h/2,0]);
for(var j=0;j<S;j++){var k=(j+1)%S;f.push([j,k,S+j],[k,S+k,S+j],[2*S,k,j],[2*S+1,S+j,S+k])}
mk(v,f,o)}
function cone(r,h,o){var S=20,v=[],f=[];
for(var j=0;j<S;j++){var t=2*Math.PI*j/S;v.push([r*Math.cos(t),-h/2,r*Math.sin(t)])}
v.push([0,h/2,0],[0,-h/2,0]);
for(var j=0;j<S;j++){var k=(j+1)%S;f.push([j,k,S],[S+1,k,j])}
mk(v,f,o)}
function exportOBJ(){var s='',off=0;meshes.forEach(function(m,i){s+='o part'+i+'\n';
m.v.forEach(function(p){s+='v '+p[0].toFixed(4)+' '+p[1].toFixed(4)+' '+p[2].toFixed(4)+'\n'});
m.f.forEach(function(f){s+='f '+(f[0]+1+off)+' '+(f[1]+1+off)+' '+(f[2]+1+off)+'\n'});off+=m.v.length});return s}
</script>
<script>/*USER*/</script>
<script>
var cv=document.getElementById('c'),ctx=cv.getContext('2d'),rx=0.4,ry=0.6,drag=null;
function size(){var d=window.devicePixelRatio||1;cv.width=Math.max(1,cv.clientWidth*d);cv.height=Math.max(1,cv.clientHeight*d);draw()}
function draw(){var W=cv.width,H=cv.height;ctx.clearRect(0,0,W,H);
var R=0.5;meshes.forEach(function(m){m.v.forEach(function(p){R=Math.max(R,Math.sqrt(p[0]*p[0]+p[1]*p[1]+p[2]*p[2]))})});
var s=Math.min(W,H)*0.38/R,cam=R*3.2,cy=Math.cos(ry),sy=Math.sin(ry),cx=Math.cos(rx),sx=Math.sin(rx);
function tf(p){var x=p[0]*cy+p[2]*sy,z=-p[0]*sy+p[2]*cy,y=p[1]*cx-z*sx;z=p[1]*sx+z*cx;return[x,y,z]}
var tris=[];
meshes.forEach(function(m){var t=m.v.map(tf);m.f.forEach(function(f){var a=t[f[0]],b=t[f[1]],c=t[f[2]];
var ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
var nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,l=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
var lit=0.3+0.7*Math.abs((nx*0.4+ny*0.7+nz*0.6)/l/1.0488);
tris.push({p:[a,b,c],z:(a[2]+b[2]+c[2])/3,c:m.c,l:lit})})});
tris.sort(function(p,q){return q.z-p.z});
tris.forEach(function(t){var st='rgb('+(t.c[0]*t.l|0)+','+(t.c[1]*t.l|0)+','+(t.c[2]*t.l|0)+')';
ctx.beginPath();t.p.forEach(function(q,i){var k=cam/(cam+q[2]),X=W/2+q[0]*s*k,Y=H/2-q[1]*s*k;if(i===0)ctx.moveTo(X,Y);else ctx.lineTo(X,Y)});
ctx.closePath();ctx.fillStyle=st;ctx.strokeStyle=st;ctx.lineWidth=0.7;ctx.fill();ctx.stroke()})}
cv.addEventListener('pointerdown',function(e){drag=[e.clientX,e.clientY];cv.setPointerCapture(e.pointerId)});
cv.addEventListener('pointermove',function(e){if(!drag)return;ry+=(e.clientX-drag[0])*0.01;rx+=(e.clientY-drag[1])*0.01;drag=[e.clientX,e.clientY];draw()});
cv.addEventListener('pointerup',function(){drag=null});
document.getElementById('b').onclick=function(){if(window.Bridge)Bridge.saveObj(exportOBJ())};
window.addEventListener('resize',size);
if(!meshes.length)msg('Empty scene');
size();
</script></body></html>"""
}
