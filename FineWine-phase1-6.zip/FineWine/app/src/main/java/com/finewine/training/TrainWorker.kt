package com.finewine.training

import android.content.Context
import androidx.work.*
import com.finewine.memory.MemoryDb
import com.finewine.memory.MemoryStore
import java.util.concurrent.TimeUnit

/** Nightly (charging + idle): builds the next training dataset with replay. Training itself runs off-phone. */
class TrainWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        runCatching { DatasetBuilder(applicationContext, MemoryStore(MemoryDb.get(applicationContext).dao())).build() }
        return Result.success()
    }
    companion object {
        fun schedule(c: Context) {
            val req = PeriodicWorkRequestBuilder<TrainWorker>(24, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiresCharging(true)
                    .setRequiresDeviceIdle(true).setRequiresBatteryNotLow(true).build()).build()
            WorkManager.getInstance(c).enqueueUniquePeriodicWork("nightly-dataset", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
