package com.finewine

import android.os.Bundle
import android.view.MotionEvent
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.finewine.tools.ObjBridge
import com.finewine.ui.ChatViewModel

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.finewine.web.LearnWorker.schedule(this)
        com.finewine.training.TrainWorker.schedule(this)
        com.finewine.training.ImproveWorker.schedule(this)
        setContent { MaterialTheme(darkColorScheme()) { Surface(Modifier.fillMaxSize()) { Chat() } } }
    }

    @Composable
    private fun Chat() {
        var input by remember { mutableStateOf("") }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let(vm::importModel) }
        val adapterPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let(vm::importAdapter) }
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(vm.status.value, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Model") }
                TextButton(onClick = { adapterPicker.launch(arrayOf("*/*")) }) { Text("Adapter") }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.messages) { m ->
                    Card(Modifier.fillMaxWidth().padding(start = if (m.fromUser) 40.dp else 0.dp, end = if (m.fromUser) 0.dp else 40.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(m.text)
                            m.html?.let { html ->
                                Spacer(Modifier.height(8.dp))
                                AndroidView(
                                    factory = { c ->
                                        WebView(c).apply {
                                            settings.javaScriptEnabled = true
                                            settings.blockNetworkLoads = true
                                            addJavascriptInterface(ObjBridge(c), "Bridge")
                                            setOnTouchListener { v, e ->
                                                if (e.action == MotionEvent.ACTION_DOWN) v.parent.requestDisallowInterceptTouchEvent(true)
                                                false
                                            }
                                            loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(300.dp)
                                )
                            }
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message or /command") })
                Button(onClick = { vm.send(input); input = "" }, enabled = !vm.busy.value) { Text("Send") }
            }
        }
    }
}
