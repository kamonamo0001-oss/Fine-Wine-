package com.finewine.web

import com.finewine.memory.MemoryStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

/** Fetches pages, cleans them to text, chunks them and stores new chunks in memory. */
class WebLearner(private val store: MemoryStore) {

    /** Learn one page. Returns number of NEW chunks stored. */
    suspend fun learnUrl(url: String): Int = withContext(Dispatchers.IO) {
        require(url.startsWith("http://") || url.startsWith("https://")) { "Only http/https links" }
        val text = htmlToText(fetch(url))
        var added = 0
        chunk(text).forEach { if (store.rememberIfNew(it, "web", url)) added++ }
        added
    }

    /** Search the web for a topic and learn the top results. Returns (pages read, new chunks). */
    suspend fun learnTopic(topic: String, maxPages: Int = 3): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val html = fetch("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(topic, "UTF-8"))
        val links = Regex("""uddg=([^&"]+)""").findAll(html)
            .map { URLDecoder.decode(it.groupValues[1], "UTF-8") }
            .filter { it.startsWith("http") }.distinct().take(maxPages).toList()
        var pages = 0; var chunks = 0
        for (l in links) runCatching { learnUrl(l) }.onSuccess { pages++; chunks += it }
        pages to chunks
    }

    private fun fetch(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) FineWineAI/0.1")
        return c.inputStream.use { it.readNBytes(300_000).toString(Charsets.UTF_8) }
    }

    private fun htmlToText(html: String): String = html
        .replace(Regex("(?is)<(script|style|noscript|svg|nav|footer|header)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("(?s)<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
        .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")
        .replace(Regex("\\s+"), " ").trim()

    private fun chunk(text: String, size: Int = 700, max: Int = 12): List<String> {
        val out = mutableListOf<String>(); var i = 0
        while (i < text.length && out.size < max) {
            var end = minOf(i + size, text.length)
            if (end < text.length) { val dot = text.lastIndexOf(". ", end); if (dot > i + 300) end = dot + 1 }
            val piece = text.substring(i, end).trim()
            if (piece.length > 120) out += piece
            i = end
        }
        return out
    }
}
