package com.finewine.memory

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity(tableName = "memories")
class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val kind: String,          // "user", "assistant", "web"
    val createdAt: Long,
    val embedding: ByteArray,
    @ColumnInfo(defaultValue = "''") val source: String = "",
    @ColumnInfo(defaultValue = "''") val hash: String = ""
)

@Dao
interface MemoryDao {
    @Insert suspend fun insert(m: MemoryEntity): Long
    @Query("SELECT * FROM memories") suspend fun all(): List<MemoryEntity>
    @Query("SELECT * FROM memories ORDER BY createdAt DESC LIMIT :n") suspend fun recent(n: Int): List<MemoryEntity>
    @Query("SELECT COUNT(*) FROM memories") suspend fun count(): Int
    @Query("UPDATE memories SET text = :t, hash = :h, embedding = :e, createdAt = :ts WHERE id = :id")
    suspend fun updateText(id: Long, t: String, h: String, e: ByteArray, ts: Long)
    @Query("SELECT COUNT(*) FROM memories WHERE hash = :h AND hash != ''") suspend fun hashCount(h: String): Int
}

@Database(entities = [MemoryEntity::class], version = 2, exportSchema = false)
abstract class MemoryDb : RoomDatabase() {
    abstract fun dao(): MemoryDao
    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE memories ADD COLUMN source TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE memories ADD COLUMN hash TEXT NOT NULL DEFAULT ''")
            }
        }
        @Volatile private var inst: MemoryDb? = null
        fun get(c: Context): MemoryDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, MemoryDb::class.java, "finewine.db")
                .addMigrations(MIGRATION_1_2).build().also { inst = it }
        }
    }
}
