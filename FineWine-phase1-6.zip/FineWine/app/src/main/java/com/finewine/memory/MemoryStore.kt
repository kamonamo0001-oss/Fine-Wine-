package com.finewine.memory

import java.security.MessageDigest

/** Every message is saved instantly; recall = similarity search blended with recency. */
class MemoryStore(private val dao: MemoryDao) {
    suspend fun remember(text: String, kind: String, source: String = "") {
        dao.insert(MemoryEntity(text = text, kind = kind, createdAt = System.currentTimeMillis(),
            embedding = Embedder.toBytes(Embedder.embed(text)), source = source, hash = sha(text)))
    }
    /** Stores only if this exact text isn't already known. Returns true if stored. */
    suspend fun rememberIfNew(text: String, kind: String, source: String): Boolean {
        if (dao.hashCount(sha(text)) > 0) return false
        remember(text, kind, source); return true
    }
    suspend fun recall(query: String, k: Int = 4): List<MemoryEntity> {
        val q = Embedder.embed(query); val now = System.currentTimeMillis()
        return dao.all().map { m ->
            val ageDays = (now - m.createdAt) / 86_400_000f
            m to (Embedder.cosine(q, Embedder.fromBytes(m.embedding)) + 0.05f / (1f + ageDays))
        }.filter { it.second > 0.15f }.sortedByDescending { it.second }.take(k).map { it.first }
    }
    suspend fun recent(n: Int = 6) = dao.recent(n).reversed()
    suspend fun count() = dao.count()
    suspend fun all() = dao.all()
    /** Rewrites a memory in place. createdAt is refreshed so the next training export treats it as new. */
    suspend fun replaceText(id: Long, text: String) =
        dao.updateText(id, text, sha(text), Embedder.toBytes(Embedder.embed(text)), System.currentTimeMillis())
    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.trim().toByteArray())
        .joinToString("") { "%02x".format(it) }
}
