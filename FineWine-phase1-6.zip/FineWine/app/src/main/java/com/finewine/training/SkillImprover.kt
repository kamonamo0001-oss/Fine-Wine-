package com.finewine.training

import android.content.Context
import com.finewine.llm.LlmEngine
import com.finewine.memory.MemoryStore
import com.finewine.tools.CodeSandbox
import com.finewine.tools.Prompts
import org.json.JSONObject
import java.io.File

/**
 * Self-improvement loop for the AI's own saved code (its JavaScript skills).
 * propose (model rewrites a skill) -> test (same output, 3 runs, deterministic) -> measure (speed / size)
 * -> keep only if clearly better -> log with full before/after so it can be undone.
 * It never touches the app's native code and never runs anything outside the no-network sandbox.
 */
class SkillImprover(
    ctx: Context,
    private val store: MemoryStore,
    private val engine: LlmEngine,
    private val sandbox: CodeSandbox
) {
    data class Report(val tried: Int, val improved: Int, val lines: List<String>)

    private val prefs = ctx.getSharedPreferences("improver", Context.MODE_PRIVATE)
    private val logFile = File(ctx.filesDir, "improvements.jsonl")
    private val marker = "Working JavaScript:\n"

    /** Runs the code 3 times. Null if it errors or its output changes between runs (can't be verified). */
    private suspend fun measure(code: String): Pair<String, Double>? {
        val outs = mutableListOf<String>()
        var best = Double.MAX_VALUE
        repeat(3) {
            val r = sandbox.run(code)
            if (r.startsWith("ERROR")) return null
            outs += r; best = minOf(best, sandbox.lastMs)
        }
        return if (outs.distinct().size == 1) outs[0] to best else null
    }

    suspend fun run(maxSkills: Int = 5): Report {
        val now = System.currentTimeMillis()
        val week = 7 * 86_400_000L
        val skills = store.all().filter {
            it.kind == "code" && it.text.contains(marker) && now - prefs.getLong("tried_${it.id}", 0L) > week
        }.shuffled().take(maxSkills)
        val lines = mutableListOf<String>()
        var improved = 0
        for (s in skills) {
            prefs.edit().putLong("tried_${s.id}", now).apply()
            val task = s.text.lineSequence().first().removePrefix("Task: ").trim()
            val code = s.text.substringAfter(marker)
            val before = measure(code)
            if (before == null) { lines += "- $task: skipped (errors, or output not repeatable)"; continue }
            var won = false
            repeat(2) {
                if (won) return@repeat
                val cand = Prompts.extractCode(engine.generate(IMPROVE_PROMPT + code))
                if (cand.isBlank() || cand == code) return@repeat
                val after = measure(cand) ?: return@repeat
                if (after.first != before.first) return@repeat           // behaviour must be identical
                val faster = after.second <= before.second * 0.85
                val smaller = after.second <= before.second * 1.05 && cand.length <= code.length * 0.9
                if (faster || smaller) {
                    val newText = s.text.substringBefore(marker) + marker + cand
                    logFile.appendText(JSONObject().put("id", s.id).put("task", task).put("ts", now)
                        .put("before", s.text).put("after", newText)
                        .put("beforeMs", before.second).put("afterMs", after.second)
                        .put("beforeLen", code.length).put("afterLen", cand.length).toString() + "\n")
                    store.replaceText(s.id, newText)
                    improved++; won = true
                    lines += "- $task: improved (%.1f -> %.1f ms, %d -> %d chars)".format(
                        before.second, after.second, code.length, cand.length)
                }
            }
            if (!won) lines += "- $task: no safe improvement found, kept as is"
        }
        return Report(skills.size, improved, lines + "Improved $improved of ${skills.size}.")
    }

    suspend fun undoLast(): String {
        val entries = if (logFile.exists()) logFile.readLines().filter { it.isNotBlank() } else emptyList()
        if (entries.isEmpty()) return "Nothing to undo."
        val last = JSONObject(entries.last())
        store.replaceText(last.getLong("id"), last.getString("before"))
        logFile.writeText(entries.dropLast(1).joinToString("") { it + "\n" })
        return "Restored the previous version of: ${last.getString("task")}"
    }

    fun log(): String {
        val entries = if (logFile.exists()) logFile.readLines().filter { it.isNotBlank() } else emptyList()
        if (entries.isEmpty()) return "No improvements yet."
        return entries.takeLast(10).joinToString("\n") {
            val j = JSONObject(it)
            "- ${j.getString("task")}: %.1f -> %.1f ms, %d -> %d chars".format(
                j.getDouble("beforeMs"), j.getDouble("afterMs"), j.getInt("beforeLen"), j.getInt("afterLen"))
        }
    }

    private companion object {
        const val IMPROVE_PROMPT = "You improve JavaScript. Rewrite the code so it produces EXACTLY the same console output " +
            "but runs faster, or is simpler and more robust. Do not change what it prints. Reply with one code block only.\nCode:\n"
    }
}
