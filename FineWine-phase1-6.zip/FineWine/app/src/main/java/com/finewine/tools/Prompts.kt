package com.finewine.tools

/** Shared prompt formats: used at inference, in the eval gate AND in training data, so they always match. */
object Prompts {
    const val CODE_RULES = "You write JavaScript that runs in a sandbox with no DOM and no network. Print results with console.log. Keep it short and self-contained."
    const val SCENE_RULES = "You build 3D models with ONLY these functions: box(w,h,d,o), sphere(r,o), cylinder(r,h,o), cone(r,h,o). " +
        "o is {x:0,y:0,z:0,color:'#rrggbb'} where x,y,z is the part's center; y is up; units are meters. Example (table):\n" +
        "box(2,0.1,1,{y:0.75,color:'#8b5a2b'});\n" +
        "for (const sx of [-0.9,0.9]) for (const sz of [-0.4,0.4]) box(0.1,0.7,0.1,{x:sx,y:0.35,z:sz,color:'#5c3a1a'});"
    const val SCENE_STUBS = "function box(){} function sphere(){} function cylinder(){} function cone(){}"

    fun codePrompt(rules: String, example: String, task: String) =
        "$rules\n$example\nTask: $task\nReply with one code block only."

    fun extractCode(r: String): String =
        Regex("```[a-zA-Z]*\\n([\\s\\S]*?)```").find(r)?.groupValues?.get(1)?.trim() ?: r.trim()
}
