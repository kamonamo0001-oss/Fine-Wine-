package com.finewine.web

import android.content.Context

/** Topics the AI keeps learning about automatically. */
object Topics {
    private fun prefs(c: Context) = c.getSharedPreferences("topics", Context.MODE_PRIVATE)
    fun all(c: Context): Set<String> = prefs(c).getStringSet("t", emptySet())!!.toSet()
    fun add(c: Context, t: String) = prefs(c).edit().putStringSet("t", all(c) + t.trim()).apply()
    fun remove(c: Context, t: String) = prefs(c).edit().putStringSet("t", all(c) - t.trim()).apply()
}
