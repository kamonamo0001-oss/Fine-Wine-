package com.finewine.training

import android.content.Context
import com.finewine.memory.MemoryStore
import com.finewine.tools.Prompts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Turns on-device memory into a fine-tuning dataset (JSONL, chat format).
 * Anti-forgetting: every export mixes NEW examples with a REPLAY sample of older ones.
 * "New" = created after the last ACCEPTED adapter, so skipped training rounds never lose data.
 */
class DatasetBuilder(private val ctx: Context, private val store: MemoryStore) {
    data class Result(val file: File?, val fresh: Int, val replay: Int, val note: String)

    private fun line(user: String, assistant: String) = JSONObject().put("messages", JSONArray()
        .put(JSONObject().put("role", "user").put("content", user))
        .put(JSONObject().put("role", "assistant").put("content", assistant))).toString()

    private fun codeExample(text: String): String? {
        val lines = text.lines()
        if (lines.size < 3) return null
        val task = lines[0].removePrefix("Task: ").trim()
        val scene = task.startsWith("3D model of ")
        val desc = task.removePrefix("3D model of ")
        val rules = if (scene) Prompts.SCENE_RULES else Prompts.CODE_RULES
        return line(Prompts.codePrompt(rules, "", desc), "```\n" + lines.drop(2).joinToString("\n") + "\n```")
    }

    suspend fun build(minNew: Int = 20): Result = withContext(Dispatchers.IO) {
        val prefs = ctx.getSharedPreferences("training", Context.MODE_PRIVATE)
        val cutoff = prefs.getLong("cutoff", 0L)
        val all = store.all().sortedBy { it.createdAt }
        val ex = mutableListOf<Pair<Long, String>>()
        all.filter { it.kind == "code" }.forEach { m -> codeExample(m.text)?.let { ex += m.createdAt to it } }
        val chat = all.filter { it.kind == "user" || it.kind == "assistant" }
        for (i in 0 until chat.size - 1) {
            val u = chat[i]; val a = chat[i + 1]
            if (u.kind == "user" && a.kind == "assistant" && !a.text.startsWith("Error") && a.text.length > 20)
                ex += a.createdAt to line(u.text, a.text)
        }
        val fresh = ex.filter { it.first > cutoff }
        val old = ex.filter { it.first <= cutoff }
        if (fresh.size < minNew) return@withContext Result(null, fresh.size, 0,
            "Only ${fresh.size} new examples (need $minNew). Skipped.")
        val replay = old.shuffled().take(minOf(old.size, maxOf(20, fresh.size / 2)))
        val dir = File(ctx.getExternalFilesDir(null), "training").apply { mkdirs() }
        val f = File(dir, "dataset-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".jsonl")
        f.writeText((fresh + replay).map { it.second }.shuffled().joinToString("\n"))
        val now = System.currentTimeMillis()
        prefs.edit().putLong("pending_cutoff", now)
            .putString("last_export", "${f.name}: ${fresh.size} new + ${replay.size} replay").apply()
        Result(f, fresh.size, replay.size, "Exported ${f.absolutePath}")
    }
}
