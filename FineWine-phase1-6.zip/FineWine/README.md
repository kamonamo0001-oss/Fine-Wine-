# Fine Wine AI - Phases 1-6
1. Open in Android Studio (generates the Gradle wrapper), Build > Build APK.
2. Import a MediaPipe-compatible model (.task or .bin). For LoRA learning (Phase 5) use a Gemma-2 2B / Gemma 2B / Phi-2 GPU build (see trainer/README.md).
Chat + memory: every message is stored and recalled on-device.
Web learning:  /learn <url or topic> | /watch <topic> | /unwatch <topic> | /topics
Tools:         /code <task> | /run <js> | /3d <thing> (drag to rotate, Save OBJ)
Training:      /train (export dataset now; also nightly) | Adapter button (import + test + keep/reject) | /adapter [rollback]
Self-improve:  /improve (try to improve saved skills now; also nightly) | /improve log | /improve undo
  A rewrite is kept only if it prints exactly the same output (3 identical runs) AND is >=15% faster or >=10% smaller.

## Get the APK without Android Studio
1. Create a GitHub repo and upload this project's contents (the .github folder must be included).
2. Open the repo's Actions tab > "Build APK" > Run workflow (it also runs on every push).
3. When it finishes (about 5 min), open the run and download the artifact "FineWine-debug-apk". Unzip it and install app-debug.apk on your phone (allow installs from unknown sources).
