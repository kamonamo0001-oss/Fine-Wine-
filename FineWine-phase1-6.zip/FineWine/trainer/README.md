# Training loop (the part a phone can't do)
1. On the phone the app builds `dataset-*.jsonl` nightly (charging + idle) or with `/train`. It mixes new examples with a replay sample of old ones.
   Find it in Android/data/com.finewine/files/training/.
2. Copy it to a PC/Colab GPU: `python train_lora.py --data dataset-....jsonl`
3. `python convert_lora.py ...` -> base.bin + lora.bin
4. First time only: import base.bin as the Model. Then tap **Adapter** and pick lora.bin.
   The app tests the new adapter against past coding tasks and keeps it only if it is at least as good. `/adapter rollback` undoes it.
Requirements: LoRA works only with Gemma-2 2B, Gemma 2B or Phi-2 converted for the GPU backend, on a phone that supports it.
The Model must be the base.bin from step 3 so the adapter matches it.
