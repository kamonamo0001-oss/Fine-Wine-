"""Convert base model + LoRA to MediaPipe format (GPU backend is required for LoRA). UNTESTED here:
check parameter names against the docs of your mediapipe version
(https://ai.google.dev/edge/mediapipe/solutions/genai/llm_inference/android#lora_customization).
pip install mediapipe
python convert_lora.py --base_ckpt ./gemma-2-2b-it-safetensors --vocab ./tokenizer.model \
       --lora_ckpt lora-out/adapter_model.safetensors --rank 8 --out converted"""
import argparse
from mediapipe.tasks.python.genai import converter

ap = argparse.ArgumentParser()
ap.add_argument("--base_ckpt", required=True)    # folder with the base model's safetensors
ap.add_argument("--vocab", required=True)        # tokenizer.model
ap.add_argument("--lora_ckpt", required=True)
ap.add_argument("--rank", type=int, default=8)
ap.add_argument("--model_type", default="GEMMA2_2B")   # GEMMA2_2B, GEMMA_2B or PHI_2 only
ap.add_argument("--out", default="converted")
a = ap.parse_args()

converter.convert_checkpoint(converter.ConversionConfig(
    input_ckpt=a.base_ckpt, ckpt_format="safetensors", model_type=a.model_type, backend="gpu",
    output_dir=a.out + "/tmp", combine_file_only=False, vocab_model_file=a.vocab,
    output_tflite_file=a.out + "/base.bin",
    lora_ckpt=a.lora_ckpt, lora_rank=a.rank, lora_output_tflite_file=a.out + "/lora.bin"))
print("Phone: import", a.out + "/base.bin", "as the Model (first time only) and", a.out + "/lora.bin", "as the Adapter.")
