"""Train an attention-only LoRA on the dataset exported by the phone (run on a PC / Colab GPU).
pip install torch transformers peft trl datasets
python train_lora.py --data dataset-YYYYMMDD-HHMM.jsonl --base google/gemma-2-2b-it --out lora-out
Replay of old examples is already mixed into the dataset by the app (anti-forgetting). UNTESTED here."""
import argparse
import torch
from datasets import load_dataset
from peft import LoraConfig
from trl import SFTConfig, SFTTrainer

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True)
ap.add_argument("--base", default="google/gemma-2-2b-it")
ap.add_argument("--out", default="lora-out")
ap.add_argument("--rank", type=int, default=8)
ap.add_argument("--epochs", type=int, default=2)
ap.add_argument("--lr", type=float, default=1e-4)   # low LR = less forgetting
a = ap.parse_args()

ds = load_dataset("json", data_files=a.data, split="train")
lora = LoraConfig(r=a.rank, lora_alpha=a.rank * 2, lora_dropout=0.05, task_type="CAUSAL_LM",
                  target_modules=["q_proj", "k_proj", "v_proj", "o_proj"])  # MediaPipe: attention layers only
cfg = SFTConfig(output_dir=a.out, num_train_epochs=a.epochs, learning_rate=a.lr,
                per_device_train_batch_size=2, gradient_accumulation_steps=8, lr_scheduler_type="cosine",
                warmup_ratio=0.05, logging_steps=10, save_strategy="no", report_to=[],
                bf16=torch.cuda.is_available() and torch.cuda.is_bf16_supported())
tr = SFTTrainer(model=a.base, train_dataset=ds, peft_config=lora, args=cfg)
tr.train()
tr.model.save_pretrained(a.out)
print("Saved adapter_model.safetensors in", a.out, "- now run convert_lora.py")
